package com.testFramework.steps.appCapital;

import java.util.HashMap;

public class ScenarioContext {
    public static HashMap<String, Object> global = new HashMap<>();
    public static HashMap<String, HashMap<String, Object>> local = new HashMap<>();
}
