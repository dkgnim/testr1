package com.testFramework.steps.appCapital;

import com.codeborne.selenide.Selenide;
import com.testFramework.appCapital.ApiPaths;
import com.testFramework.appCapital.Constants;
import com.testFramework.appCapital.models.apiAccounts.activate.request.AccountsActivateReq;
import com.testFramework.appCapital.models.apiAccounts.auth.AccountsAuthReq;
import com.testFramework.appCapital.models.apiAccounts.auth.AccountsAuthResp;
import com.testFramework.appCapital.models.apiAccounts.auth.AccountsSignInRefreshReq;
import com.testFramework.appCapital.models.apiAccounts.changePassword.AccountsChangePassAdmReq;
import com.testFramework.appCapital.models.apiAccounts.changePassword.AccountsChangePassAuthUsrReq;
import com.testFramework.appCapital.models.apiAccounts.changePassword.AccountsChangePassNoAuthPostUsrReq;
import com.testFramework.appCapital.models.apiAccounts.changePassword.AccountsChangePassNoAuthWithCodeUsrReq;
import com.testFramework.appCapital.models.apiAccounts.createAccount.AccountsCreateAccountReq;
import com.testFramework.appCapital.models.apiAccounts.updateAccount.AccountsUpdateAccByIdReq;
import com.testFramework.appCapital.models.apiAccounts.updateAccount.AccountsUpdateMyAccReq;
import com.testFramework.core.RestHandler;
import com.testFramework.core.TempMailHandler;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;

import static com.testFramework.core.RestHandler.RequestType.*;

public class AccountsSteps {

    Scenario scenario;

    @Before
    public void before(Scenario scenario) {
        this.scenario = this.scenario == null ? scenario : this.scenario;
        this.baseSteps = this.baseSteps == null ? new BaseSteps(scenario) : this.baseSteps;
    }

    private final RestHandler restHandler = new RestHandler();
    private final ApiPaths apiPaths = new ApiPaths();
    private final Constants constants = new Constants();
    private final TempMailHandler tempMailHandler = new TempMailHandler();
    private BaseSteps baseSteps;

    @Given("SignIn exist token {string} or request and save new one, as predefinedUser {string}")
    public void checkSignInTokensOrRequestNewOne(String tokenVar, String userRole) {
        String realToken = "";
        if (tokenVar.endsWith("_l") || tokenVar.endsWith("_g")) {
            realToken = String.valueOf(baseSteps.getSavedContextVarIfExist(
                    tokenVar, false));
        } else {
            Assert.fail("Token name " + tokenVar + " must ends with _g or _l suffix to get this vars from context.");
        }
        if (!realToken.contains("Bearer")) {
            sendSignInRequestAndSaveAs("AuthResponseTmp", userRole);
            Response response = (Response) baseSteps.getSavedContextVarIfExist
                    ("AuthResponseTmp", true);
            Assert.assertEquals(200, response.getStatusCode());
            realToken = response.as(AccountsAuthResp.class).getAccess();
            baseSteps.saveToScenarioContext(tokenVar, realToken);
        }
        System.out.println(); // debug
    }

    @Given("Send sign in request and save RAW answer as {string} under {string}")
    public void sendSignInRequestAndSaveAs(String saveAsVarName, String userRole) {
        AccountsAuthReq accountsAuthReq = new AccountsAuthReq();
        accountsAuthReq.setEmail(constants.getEmail(userRole));
        accountsAuthReq.setPassword(constants.getPassword(userRole));
        Response response = restHandler.sendRequestViaJson(POST, apiPaths.accSignIn,
                accountsAuthReq);
        baseSteps.saveToScenarioContext(saveAsVarName, response);
    }

    @Given("SignIn request and save RAW answer as {string} with: email {string} pass {string}")
    public void sendSignInRequestWithCredsAndSaveAs
            (String saveAsVarName, String email, String password) {
        AccountsAuthReq accountsAuthReq = new AccountsAuthReq();
        if (password.endsWith("_l") || password.endsWith("_g")) {
            accountsAuthReq.setPassword(String.valueOf(
                    baseSteps.getSavedContextVarIfExist(password, true)));
        } else {
            accountsAuthReq.setPassword(String.valueOf(
                    baseSteps.getSavedContextVarIfExist(password, false)));
        }
        if (email.endsWith("_l") || email.endsWith("_g")) {
            accountsAuthReq.setEmail(String.valueOf(
                    baseSteps.getSavedContextVarIfExist(email, true)));
        } else {
            accountsAuthReq.setEmail(String.valueOf(
                    baseSteps.getSavedContextVarIfExist(email, false)));
        }
        baseSteps.saveToScenarioContext(saveAsVarName,
                restHandler.sendRequestViaJson(POST, apiPaths.accSignIn,
                        accountsAuthReq));
    }

    @When("Send sign in refresh with refresh token {string} and save RAW answer as {string}")
    public void sendSignInRequestWithTokenAndSaveResult(String refreshTokenVar, String saveAsVarName) {
        AccountsSignInRefreshReq requestObj = new AccountsSignInRefreshReq();
        requestObj.setToken(String.valueOf(
                baseSteps.getSavedContextVarIfExist(refreshTokenVar, true)));
        Response response = restHandler.sendRequestViaJson(POST,
                apiPaths.accSignInRefresh, requestObj);
        baseSteps.saveToScenarioContext(saveAsVarName, response);
    }

    @Then("Send sign out request with access token {string} and save RAW answer as {string}")
    public void sendSignOutRequestAndSaveAs(String accessToken, String saveAsVarName) {
        Response response = restHandler.sendRequestViaJson(POST,
                apiPaths.accSignOut, "", "Accept-Charset", "UTF-8", "Accept-Language",
                "en", "Api-Key", "", "Api-Version", "", "App-Name", "", "App-Version", "", "Content-Type",
                "", "Device-Id", "",
                "Authorization", String.valueOf(
                        baseSteps.getSavedContextVarIfExist(accessToken, true)),
                "Platform", "Undefined, iOS, Android, Web, Server, Desktop", "Session-Id", "");
        baseSteps.saveToScenarioContext(saveAsVarName, response);
    }

    @When("Save refresh as {string} & access as {string} tokens from {string}")
    public void saveTokensFromVar(String refreshTokenVar, String accessTokenVar,
                                  String authResponseVar) {
        AccountsAuthResp authResponse = (AccountsAuthResp)
                baseSteps.getSavedContextVarIfExist(authResponseVar, true);
        baseSteps.saveToScenarioContext(refreshTokenVar, authResponse.getRefresh());
        baseSteps.saveToScenarioContext(accessTokenVar, authResponse.getAccess());
    }

    @Then("Assert string {string} should be different then string {string}")
    public void twoStringShouldBeDifferent(String first, String second) {
        Assert.assertNotEquals(
                String.valueOf(baseSteps.getSavedContextVarIfExist(
                        first, true)),
                String.valueOf(baseSteps.getSavedContextVarIfExist(
                        second, true)));
    }

    @Then("Assert string {string} ans string {string} should be equals")
    public void twoStringShouldBeEquals(String first, String second) {
        Assert.assertEquals(
                String.valueOf(baseSteps.getSavedContextVarIfExist(
                        first, true)),
                String.valueOf(baseSteps.getSavedContextVarIfExist(
                        second, true)));
    }

    @When("Get and check status response code {int} from {string}")
    public void getAndCheckStatusResponseCode(Integer expectedCode, String varName) {
        String responseAsString =
                ((Response) baseSteps.getSavedContextVarIfExist(varName, true)).asString();
        responseAsString = responseAsString.contains("Incorrect route") ? "Seems like you use incorrect " +
                "ENDPOINT path or REQUEST type! Full response string:\n\n" + responseAsString : responseAsString;
        Assertions.assertEquals(expectedCode, ((Response) baseSteps.getSavedContextVarIfExist(
                        varName, true)).getStatusCode(),
                responseAsString + "\n\n");
    }

    @When("Bind temp email address {string} timeoutSec {string}")
    public void bindEmailAddress(String varName, String timeoutSec) {
        String email = String.valueOf(baseSteps
                        .getSavedContextVarIfExist(varName, false))
                .replace("@mailto.plus", "");
        tempMailHandler.bindMailAddress(email, Long.valueOf(timeoutSec));
    }

    @When("Get code from tempMail address {string} for {string} sec and save as {string}")
    public void getCodeFromEmail(String varName, String timeToWait, String saveAs) {
        String email = String.valueOf(baseSteps
                        .getSavedContextVarIfExist(varName, false))
                .replace("@mailto.plus", "");
        String code = tempMailHandler.waitAndGetMail
                        (email, Long.valueOf(timeToWait))
                .replace("https://tempmail.plus/appcapital.vc/email-confirm?code=", "")
                .replace("https://tempmail.plus/appcapital.vc/password-reset?code=", "");
        baseSteps.saveToScenarioContext(saveAs, code);
        Selenide.closeWebDriver();
    }

    /**
     * Use VOID value for field to create request WITHOUT this field
     */
    @When("UpdateMyAccount: token {string}, firstName {string} lastName {string}, saveAs {string}")
    public void updateMyAccountRequest(String token, String firstName, String lastName,
                                       String saveAsVarName) {
        AccountsUpdateMyAccReq request = new AccountsUpdateMyAccReq();
        if (!firstName.equals("void")) {
            request.setFirstName(String.valueOf(
                    baseSteps.getSavedContextVarIfExist(firstName, false)));
        }
        if (!lastName.equals("void")) {
            request.setLastName(String.valueOf(
                    baseSteps.getSavedContextVarIfExist(lastName, false)));
        }
        Response response = restHandler.sendRequestViaJson(PUT,
                apiPaths.accGetMyAccount, request, "Authorization",
                String.valueOf(baseSteps.getSavedContextVarIfExist(token, true)));
        baseSteps.saveToScenarioContext(saveAsVarName, response);
    }

    @When("ActivateAccount request with code {string} and save as {string}")
    public void sendActivationRequest(String activationCode, String saveAsVarName) {
        String code = String.valueOf(baseSteps
                .getSavedContextVarIfExist(activationCode, false));
        AccountsActivateReq request = new AccountsActivateReq();
        request.setCode(code);
        Response response = restHandler.sendRequestViaJson(POST,
                apiPaths.accEmailActivate, request);
        baseSteps.saveToScenarioContext(saveAsVarName, response);
    }

    @Then("Assert not null fields in auth response from {string}")
    public void assertNotNullFieldsInAuthResponse(String varName) {
        AccountsAuthResp authResponse =
                (AccountsAuthResp) baseSteps.getSavedContextVarIfExist(varName, true);
        Assertions.assertNotNull(authResponse.getAccess());
        Assertions.assertNotNull(authResponse.getRefresh());
    }

    @Then("Assert not empty fields in auth response from {string}")
    public void assertNotEmptyFieldsInAuthResponse(String varName) {
        AccountsAuthResp authResponse =
                (AccountsAuthResp) baseSteps.getSavedContextVarIfExist(varName, true);
        Assertions.assertNotEquals("", authResponse.getAccess());
        Assertions.assertNotEquals("", authResponse.getRefresh());
    }

    @Then("GetMyAccount request, with token {string}, save RAW result as {string}")
    public void sendGetMyAccountRequestAndSaveAs(String tokenVar, String saveAsVarName) {
        baseSteps.saveToScenarioContext(saveAsVarName, restHandler.sendRequestWithHeadersAndFormParams(
                GET, apiPaths.accGetMyAccount,
                restHandler.getBasicRequestSpec(),
                new String[]{"Authorization", String.valueOf((baseSteps.getSavedContextVarIfExist
                        (tokenVar, true)))},
                new String[]{}));
    }

    @Then("GetAccountsList page {string} pageSize {string}, token {string}, save RAW result as {string}")
    public void sendGetAccountsListAndSaveAs(String page, String pageSize, String tokenVar,
                                             String saveAsVarName) {
        baseSteps.saveToScenarioContext(saveAsVarName, restHandler.sendRequestWithHeadersAndParams(
                GET, apiPaths.accAccountsAdmin,
                new String[]{"Authorization", String.valueOf((baseSteps.getSavedContextVarIfExist
                        (tokenVar, true))),
                        "Accept-Charset", "UTF-8", "Accept-Language", "en"},
                new String[]
                        {"page", page, "pageSize", pageSize}
        ));
    }

    @Then("GetAccountsList with token {string}, save RAW result as {string}")
    public void sendGetAccountsListAndSaveAs(String tokenVar, String saveAsVarName) {
        baseSteps.saveToScenarioContext(saveAsVarName, restHandler.sendRequestWithHeadersAndParams(
                GET, apiPaths.accAccountsAdmin,
                new String[]{"Authorization", String.valueOf((baseSteps.getSavedContextVarIfExist
                        (tokenVar, true))),
                        "Accept-Charset", "UTF-8", "Accept-Language", "en"},
                new String[]{}
        ));
    }

    @Then("GetAccountsListById with token {string}, for userId {string} save RAW result as {string}")
    public void sendGetAccountsListWithUserIdAndSaveAs(String tokenVar, String userId,
                                                       String saveAsVarName) {
        if (userId.endsWith("_g") || userId.endsWith("_l")) {
            userId = String.valueOf(baseSteps
                    .getSavedContextVarIfExist(userId, false));
        }
        baseSteps.saveToScenarioContext(saveAsVarName, restHandler.sendRequestWithHeadersAndParams(
                GET, apiPaths.accAccountsAdmin + "/" + userId,
                new String[]{"Authorization", String.valueOf((baseSteps.getSavedContextVarIfExist
                        (tokenVar, true))),
                        "Accept-Charset", "UTF-8", "Accept-Language", "en"},
                new String[]{}
        ));
    }

//    @Then("CreateAccountBy {string} with {string}, savedVars: {string} {string} {string} nonSaved: {string} {string}, save as {string}")
//    public void sendCreateAccountFromStoredVariablesAndSaveAs
//            (String userRole, String tokenVar, String firstName, String lastName, String email, String isActive,
//             String isAdmin, String saveAsVarName) {
//
//        sendCreateAccountAndSaveAs(userRole, tokenVar,
//                String.valueOf(scenarioContext.get(firstName)),
//                String.valueOf(scenarioContext.get(lastName)),
//                String.valueOf(scenarioContext.get(email)),
//                isActive, isAdmin, saveAsVarName);
//    }

    @Then("CreateAccountBy {string} token {string}, data: {string} {string} {string}, save as {string}")
    public void sendCreateAccountAndSaveAs(String userRole, String tokenVar, String firstName,
                                           String lastName, String email, String saveAsVarName) {
        sendCreateAccountAndSaveAs(userRole, tokenVar, firstName, lastName, email,
                "void", "void", saveAsVarName);
    }

    /**
     * Use VOID value for field to create request WITHOUT this field
     */
    @Then("CreateAccount role {string} token {string} , data: {string} {string} {string} {string} {string}, save as {string}")
    public void sendCreateAccountAndSaveAs(String userRole, String tokenVar, String firstName,
                                           String lastName, String email, String isActive, String isAdmin, String saveAsVarName) {
        AccountsCreateAccountReq request = new AccountsCreateAccountReq();
        if (!firstName.equals("void")) {
            request.setFirstName
                    (String.valueOf(baseSteps.getSavedContextVarIfExist(
                            firstName, false)));
        }
        if (!lastName.equals("void")) {
            request.setLastName
                    (String.valueOf(baseSteps.getSavedContextVarIfExist(
                            lastName, false)));
        }
        if (!email.equals("void")) {
            request.setEmail
                    (String.valueOf(baseSteps.getSavedContextVarIfExist(
                            email, false)));
        }
        if (!isActive.equals("void")) {
            request.setIsActive
                    (Boolean.valueOf
                            (String.valueOf(baseSteps.getSavedContextVarIfExist(
                                    isActive, false))));
        }
        if (!isAdmin.equals("void")) {
            request.setIsAdmin
                    (Boolean.valueOf
                            (String.valueOf(baseSteps.getSavedContextVarIfExist(
                                    isAdmin, false))));
        }
        String apiPath = userRole.contains("user") ? apiPaths.accAccountsUser : apiPaths.accAccountsAdmin;
        Response response = restHandler.sendRequestViaJson
                (POST, apiPath, request,
                        "Authorization", String.valueOf((baseSteps.getSavedContextVarIfExist
                                (tokenVar, true))),
                        "Accept-Charset", "UTF-8", "Accept-Language", "en");
        baseSteps.saveToScenarioContext(saveAsVarName, response);
    }

    @Then("DeleteAccById: {string}, token {string} saveAs {string}")
    public void sendDeleteAccountById(String accountId, String tokenVar, String saveAsVarName) {
        if (accountId.endsWith("_g") || accountId.endsWith("_l")) {
            accountId = String.valueOf(baseSteps
                    .getSavedContextVarIfExist(accountId, true));
        }
        String path = apiPaths.accAccountsAdmin + "/" + accountId;
        baseSteps.saveToScenarioContext(saveAsVarName, restHandler.sendRequestViaJson
                (DELETE, path, "",
                        "Authorization", String.valueOf((baseSteps.getSavedContextVarIfExist
                                (tokenVar, true))),
                        "Accept-Charset", "UTF-8", "Accept-Language", "en"));
    }

    @Then("DeleteMyAccount: token {string}, save response {string}")
    public void sendDeleteMyAccount(String tokenVar, String saveAsVarName) {
        if (tokenVar.endsWith("_g") || tokenVar.endsWith("_l")) {
            tokenVar = String.valueOf(baseSteps.getSavedContextVarIfExist(
                    tokenVar, true));
        }
        baseSteps.saveToScenarioContext(saveAsVarName, restHandler.sendRequestViaJson
                (DELETE, apiPaths.accGetMyAccount, "",
                        "Authorization", tokenVar,
                        "Accept-Charset", "UTF-8", "Accept-Language", "en"));
    }

    @Then("Get context variable and show as string: {string}")
    public void showContextVarAsString(String varName) {
        Object object = baseSteps.getSavedContextVarIfExist(varName, true);
        if (object instanceof Response) {
            Response response = (Response) object;
            System.out.println("\n\n|| RAW answer and code for " + varName + " ||\nCode: "
                    + response.getStatusCode() + "\nAnswer (sometime can be empty):\n\n"
                    + response.asString() + "\n\n");
        } else {
            System.out.println("\n\n|| Variable value for " + varName + " ||\n\n" + object + "\n\n");
        }
    }

    @Then("ChangePassWithAuth: oldPass {string} newPass {string} token {string} save response as {string} byUsr")
    public void sendChangePasswordWithAuthByUsr(String oldPass, String newPass,
                                                String tokenVar, String saveAsVarName) {
        AccountsChangePassAuthUsrReq request = new AccountsChangePassAuthUsrReq();
        if (!oldPass.equals("void")) {
            if (oldPass.endsWith("_l") || oldPass.endsWith("_g")) {
                request.setOldPassword(
                        String.valueOf(baseSteps
                                .getSavedContextVarIfExist(oldPass, true)));
            } else {
                request.setOldPassword(
                        String.valueOf(baseSteps
                                .getSavedContextVarIfExist(oldPass, false)));
            }
        }
        if (!newPass.equals("void")) {
            if (newPass.endsWith("_l") || newPass.endsWith("_g")) {
                request.setNewPassword(
                        String.valueOf(baseSteps
                                .getSavedContextVarIfExist(newPass, true)));
            } else {
                request.setNewPassword(
                        String.valueOf(baseSteps
                                .getSavedContextVarIfExist(newPass, false)));
            }
        }
        baseSteps.saveToScenarioContext(saveAsVarName, restHandler.sendRequestViaJson
                (PUT, apiPaths.accChangePassAuthUsr, request,
                        "Authorization", String.valueOf((baseSteps.getSavedContextVarIfExist
                                (tokenVar, true))),
                        "Accept-Charset", "UTF-8", "Accept-Language", "en"));
    }

    @Then("ChangePassNoAuth: email {string} save response as {string} byUsr")
    public void sendChangePasswordNoAuthByUsr(String email, String saveAsVarName) {
        AccountsChangePassNoAuthPostUsrReq request = new AccountsChangePassNoAuthPostUsrReq();
        if (!email.equals("void")) {
            request.setEmail(
                    String.valueOf(baseSteps.getSavedContextVarIfExist(email, true)));
        }
        baseSteps.saveToScenarioContext(saveAsVarName, restHandler.sendRequestViaJson
                (POST, apiPaths.accChangePassNoAuthUsr, request,
                        "Accept-Charset", "UTF-8", "Accept-Language", "en"));
    }

    @Then("ChangePassNoAuth: code {string} pass {string} passRetype {string}, save response as {string} byUsr")
    public void sendChangePasswordNoAuthWithCodeByUsr(String code, String pass, String passRetype,
                                                      String saveAsVarName) {
        AccountsChangePassNoAuthWithCodeUsrReq request = new AccountsChangePassNoAuthWithCodeUsrReq();
        if (!code.equals("void")) {
            request.setCode(
                    String.valueOf(baseSteps
                            .getSavedContextVarIfExist(code, true)));
        }
        if (!pass.equals("void")) {
            request.setPassword(
                    String.valueOf(baseSteps
                            .getSavedContextVarIfExist(pass, true)));
        }
        if (!passRetype.equals("void")) {
            request.setPasswordRetype(
                    String.valueOf(baseSteps
                            .getSavedContextVarIfExist(passRetype, true)));
        }
        baseSteps.saveToScenarioContext(saveAsVarName, restHandler.sendRequestViaJson
                (PUT, apiPaths.accChangePassNoAuthUsr, request,
                        "Accept-Charset", "UTF-8", "Accept-Language", "en"));
    }

    @Then("ChangePass: token {string} userId {string} newPass {string}, save response as {string}  byAdm")
    public void sendChangePasswordByAdm(String tokenVar, String userId, String newPassword, String saveAsVarName) {
        AccountsChangePassAdmReq request = new AccountsChangePassAdmReq();
        if (newPassword.endsWith("_l") || newPassword.endsWith("_g")) {
            request.setPassword(
                    String.valueOf(baseSteps
                            .getSavedContextVarIfExist(newPassword, true)));
        } else {
            request.setPassword(
                    String.valueOf(baseSteps
                            .getSavedContextVarIfExist(newPassword, false)));
        }
        userId = userId.endsWith("_g") || userId.endsWith("_l") ?
                String.valueOf(baseSteps
                        .getSavedContextVarIfExist(userId, true)) : userId;
        String apiPath = apiPaths.accChangePassAdm + userId + "/set-password";
        baseSteps.saveToScenarioContext(saveAsVarName, restHandler.sendRequestViaJson
                (PUT, apiPath, request,
                        "Authorization", String.valueOf((baseSteps.getSavedContextVarIfExist
                                (tokenVar, true))),
                        "Accept-Charset", "UTF-8", "Accept-Language", "en"));
    }

    @Then("LockAccById: {string}, token {string} saveAs {string}")
    public void sendLockAccountById(String accountId, String tokenVar, String saveAsVarName) {
        accountId = String.valueOf(baseSteps
                .getSavedContextVarIfExist(accountId, false));
        String path = apiPaths.accAccountsAdmin + "/" + accountId + "/lock";
        baseSteps.saveToScenarioContext(saveAsVarName, restHandler.sendRequestViaJson
                (PUT, path, "",
                        "Authorization", String.valueOf((baseSteps.getSavedContextVarIfExist
                                (tokenVar, true))),
                        "Accept-Charset", "UTF-8", "Accept-Language", "en"));
    }

    @Then("UnlockAccById: {string}, token {string} saveAs {string}")
    public void sendUnlockAccountById(String accountId, String tokenVar, String saveAsVarName) {
        accountId = String.valueOf(baseSteps
                .getSavedContextVarIfExist(accountId, false));
        String path = apiPaths.accAccountsAdmin + "/" + accountId + "/unlock";
        baseSteps.saveToScenarioContext(saveAsVarName, restHandler.sendRequestViaJson
                (PUT, path, "",
                        "Authorization", String.valueOf((baseSteps.getSavedContextVarIfExist
                                (tokenVar, true))),
                        "Accept-Charset", "UTF-8", "Accept-Language", "en"));
    }

    /**
     * @param firstName can be absent, just write word 'absent'
     * @param lastName  can be absent, just write word 'absent'
     */
    @Then("UpdateAccById: {string}, token {string}, data: {string} {string}, saveAs {string}")
    public void sendUpdateAccountByIdAndSaveAs(String accountId, String tokenVar,
                                               String firstName, String lastName, String saveAsVarName) {
        AccountsUpdateAccByIdReq request = new AccountsUpdateAccByIdReq();
        if (accountId.endsWith("_l") || accountId.endsWith("_g")) {
            accountId = String.valueOf(baseSteps
                    .getSavedContextVarIfExist(accountId, true));
        }
        if (!firstName.contains("absent")) {
            if (firstName.endsWith("_g") || firstName.endsWith("_l")) {
                request.setFirstName(String.valueOf(
                        baseSteps.getSavedContextVarIfExist(firstName, true)));
            } else {
                request.setFirstName(firstName);
            }
        }
        if (!lastName.contains("absent")) {
            if (lastName.endsWith("_g") || lastName.endsWith("_l")) {
                request.setLastName(String.valueOf(
                        baseSteps.getSavedContextVarIfExist(lastName, true)));
            } else {
                request.setLastName(lastName);
            }
        }
        String path = apiPaths.accAccountsAdmin + "/" + accountId;
        baseSteps.saveToScenarioContext(saveAsVarName, restHandler.sendRequestViaJson
                (PUT, path, request,
                        "Authorization", String.valueOf((baseSteps.getSavedContextVarIfExist
                                (tokenVar, true))),
                        "Accept-Charset", "UTF-8", "Accept-Language", "en"));
    }

    @Then("DeleteAccountById {string} with token {string} and save response as {string}")
    public void deleteAccountById(String accountId, String tokenVar, String saveResponseAs) {
        accountId = String.valueOf(baseSteps
                .getSavedContextVarIfExist(accountId, false));
        Response response = restHandler.sendRequestViaJson(DELETE,
                apiPaths.accAccountsAdmin + "/" + accountId, "",
                "Authorization", String.valueOf((baseSteps.getSavedContextVarIfExist
                        (tokenVar, true))),
                "Accept-Charset", "UTF-8", "Accept-Language", "en");
        baseSteps.saveToScenarioContext(saveResponseAs, response);
    }
}
