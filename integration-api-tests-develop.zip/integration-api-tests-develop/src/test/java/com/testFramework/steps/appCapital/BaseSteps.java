package com.testFramework.steps.appCapital;

import com.testFramework.appCapital.ApiPaths;
import com.testFramework.appCapital.Constants;
import com.testFramework.core.Generator;
import com.testFramework.core.RestHandler;
import com.testFramework.core.TempMailHandler;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;
import org.junit.Assert;
import org.reflections.Reflections;
import org.reflections.scanners.SubTypesScanner;
import org.reflections.util.ClasspathHelper;
import org.reflections.util.ConfigurationBuilder;
import org.reflections.util.FilterBuilder;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.*;

public class BaseSteps {

    Scenario scenario;
    RestHandler restHandler = new RestHandler();

    public BaseSteps() {
    } // need for cucumber runner

    public BaseSteps(Scenario scenario) {
        this.scenario = scenario;
    }

    @Before
    public void before(Scenario scenario) {
        this.scenario = this.scenario == null ? scenario : this.scenario;
    }

    protected void saveToScenarioContext(String key, Object value) {
        if (key.endsWith("_g")) {
            key = key.substring(0, key.lastIndexOf("_g"));
            ScenarioContext.global.put(key, value);
            return;
        } else {
            key = key.endsWith("_l") ? key.substring(0, key.lastIndexOf("_l")) : key;
            String scenarioName = scenario.getName();
            if (ScenarioContext.local.containsKey(scenarioName)) {
                ScenarioContext.local.get(scenarioName).put(key, value);
            } else {
                String finalKey = key;
                ScenarioContext.local.put(scenarioName, new HashMap<String, Object>() {{
                    put(finalKey, value);
                }});
            }
        }
        System.out.println(); // debug
    }

    @Given("Generate email with length {string} and save as {string}")
    public void generateEmailAndSaveAs(String length, String saveAsVariable) {
        saveToScenarioContext(saveAsVariable,
                Generator.string(Integer.parseInt(length),
                        false, true, true, false,
                        false) + "@mailto.plus");
    }

    @Given("GenerateString {string}, length {string} cyrillic {string} latin {string} numeric {string} spaces {string} symbols {string}")
    public void generateString(String saveAsVariable, String length, String cyr, String latin, String num, String spaces,
                               String symbols) {
        saveToScenarioContext(saveAsVariable,
                Generator.string(Integer.parseInt(length),
                        Boolean.parseBoolean(cyr),
                        Boolean.parseBoolean(latin),
                        Boolean.parseBoolean(num),
                        Boolean.parseBoolean(spaces),
                        Boolean.parseBoolean(symbols)));
    }

    @Given("CreateString {string}, and save as {string}")
    public void createString(String incString, String saveAsVariable) {
        saveToScenarioContext(saveAsVariable, incString);
    }

    @Given("Get current date and save as {string}")
    public void getCurrentDate(String saveAsVariable) {
        String stringDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        saveToScenarioContext(saveAsVariable, stringDate);
    }

    private String makeGetterName(String value) {
        if (value.matches("[0-9]+")) { // contains number
            return "get(" + value.substring(0, 1).toUpperCase() + value.substring(1) + ")";
        }
        return "get" + value.substring(0, 1).toUpperCase() + value.substring(1);
    }

    private String makeSetterName(String value) {
        if (value.matches("[0-9]+")) { // contains number
            return "set(" + value.substring(0, 1).toUpperCase() + value.substring(1) + ")";
        }
        return "set" + value.substring(0, 1).toUpperCase() + value.substring(1);
    }

    public ArrayList<String> parseModelFieldNameToGetters(String modelFieldName) {
        ArrayList<String> innerObjectsGetMethodNames = new ArrayList<>();
        if (modelFieldName.contains(".")) {
            int innerObjectDeep = (int) modelFieldName.chars().filter(ch -> ch == '.').count();
            String tmpModelFieldName = new String(modelFieldName);
            for (int i = 0; i <= innerObjectDeep; i++) {
                String getterMethodName = "";
                if (tmpModelFieldName.contains(".")) {
                    getterMethodName = (tmpModelFieldName.substring(0, tmpModelFieldName.indexOf(".")));
                } else {
                    getterMethodName = tmpModelFieldName;
                }
                getterMethodName = makeGetterName(getterMethodName);
                tmpModelFieldName =
                        tmpModelFieldName.substring(tmpModelFieldName.indexOf(".") + 1);
                innerObjectsGetMethodNames.add(getterMethodName);
            }
        } else {
            innerObjectsGetMethodNames.add(makeGetterName(modelFieldName));
        }
        return innerObjectsGetMethodNames;
    }

    private String searchClassNameInProject(String classNameToFindOut) {
        Set<String> classesSet = new Reflections(new ConfigurationBuilder()
                .filterInputsBy(new FilterBuilder().includePackage("com.testFramework"))
                .setUrls(ClasspathHelper.forPackage("com.testFramework"))
                .setScanners(new SubTypesScanner(false))).getAllTypes();
        for (String className : classesSet) {
            try {
                if (className.contains(classNameToFindOut) && !className.equals("")) {
                    return className;
                }
            } catch (Exception ignored) {
            }
        }
        Assert.fail("classNameToFindOut: " + classNameToFindOut + " not found.");
        return null;
    }

    protected Object getSavedScenarioContextVar(String variableName, boolean isGlobal,
                                                boolean failIfEmpty) {
        String scenarioName = scenario.getName();
        String globalModeForError = isGlobal ? "global" : "local";
        Object storedObject = null;
        if (isGlobal) {
            storedObject = ScenarioContext.global.get(variableName);
        } else {
            HashMap<String, Object> stringObjectHashMap = ScenarioContext.local.get(scenarioName);
            if (stringObjectHashMap != null) {
                storedObject = ScenarioContext.local.get(scenarioName).get(variableName);
            }
        }
        if (storedObject == null && failIfEmpty) {
            Assert.fail("Object " + variableName + " was not found in saved variables of " + globalModeForError +
                    " scenario context. Check variable name!");
        }
        if (storedObject != null) {
            return storedObject;
        } else {
            return variableName;
        }
    }

    protected Object getSavedScenarioContextVar(String variableName) {
        return
                getSavedScenarioContextVar(variableName, false, true);
    }

    protected Object getSavedContextVarIfExist(String variableName, boolean failIfEmpty) {
        Object variableObject;
        if (variableName.endsWith("_g")) {
            variableName = variableName.substring(0, variableName.lastIndexOf("_g"));
            variableObject =
                    getSavedScenarioContextVar(
                            variableName.replace("_g", ""),
                            true, failIfEmpty);
        } else if (variableName.endsWith("_l")) {
            variableName = variableName.substring(0, variableName.lastIndexOf("_l"));
            variableObject =
                    getSavedScenarioContextVar(
                            variableName.replace("_l", ""),
                            false, failIfEmpty);
        } else {
            variableObject = getSavedScenarioContextVar(
                    variableName, false, failIfEmpty);
        }
        if (variableObject != null) {
            return variableObject;
        }
        return variableName;
    }

    private Object invokeMethodFromObject(Object objectToInvoke, String methodName) {
        return invokeMethodFromObject(objectToInvoke, methodName, new Object[]{});
    }

    private Object invokeMethodFromObject(Object objectToInvoke, String methodName, Object... args) {
        if (args.length == 0) {
            try {
                Method method = objectToInvoke.getClass().getMethod(methodName);
                return method.invoke(objectToInvoke);
            } catch (Exception ignored) {
            }
        } else {
            try {
                Method method = null;
                if (args[0] instanceof Integer) {
                    method = objectToInvoke.getClass().getMethod(methodName, int.class);
                    return method.invoke(objectToInvoke, args[0]);
                }
                if (args[0] instanceof String) {
                    method = objectToInvoke.getClass().getMethod(methodName, String.class);
                    return method.invoke(objectToInvoke, args[0]);
                }
                if (args[0] instanceof Double) {
                    method = objectToInvoke.getClass().getMethod(methodName, Double.class);
                    return method.invoke(objectToInvoke, args[0]);
                }
                if (args[0] instanceof Long) {
                    method = objectToInvoke.getClass().getMethod(methodName, Long.class);
                    return method.invoke(objectToInvoke, args[0]);
                }
                if (method == null) {
                    Assert.fail("Cant identify method args type: " + Arrays.toString(args));
                }
            } catch (Exception ignored) {
            }
        }
        Assert.fail("\n\nCan't invoke method (maybe field name error or this field doesn't exist in object): "
                + methodName + "\n\nFrom object:\n " + objectToInvoke + "\n");
        return null;
    }

    protected String changeGlobalVarNameForRole(String varName, String userRole) {
        return varName + ("_" + userRole);
    }

    @Given("Create object as model {string} and save as {string}")
    public void createObjectAsModelAndSaveAs(String modelName, String saveAsVar) {
        Object object;
        try {
            Class cls = Class.forName(searchClassNameInProject(modelName));
            object = cls.newInstance();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        saveToScenarioContext(saveAsVar, object);
    }

    @Given("SetObj {string}: field {string} val {string}")
    public void updateObject(String objectContextVarName, String fieldName, String fieldValue){
        ArrayList<String> fieldsName = new ArrayList<>();
        fieldsName.add(fieldName);
        ArrayList<String> fieldsValue = new ArrayList<>();
        fieldsValue.add(fieldValue);
        updateObjectAndSetData(objectContextVarName, fieldsName, fieldsValue);
    }

    @Given("SetObj {string}: field {string} val {string}, field {string} val {string}")
    public void updateObject(String objectContextVarName, String fieldName, String fieldValue, String fieldName2,
                             String fieldValue2){
        ArrayList<String> fieldsName = new ArrayList<>();
        fieldsName.add(fieldName);
        fieldsName.add(fieldName2);
        ArrayList<String> fieldsValue = new ArrayList<>();
        fieldsValue.add(fieldValue);
        fieldsValue.add(fieldValue2);
        updateObjectAndSetData(objectContextVarName, fieldsName, fieldsValue);
    }

    @Given("CreateHeaders: key {string} value {string}, saveAsVar {string}")
    public void createHeaders(String headerKey, String headerValue, String saveAsVar){
        String[] strings = new String[2];
        strings[0] = headerKey;
        strings[1] = headerValue;
        saveToScenarioContext(saveAsVar, strings);
    }

    @Given("SendRequest: type {string} path {string} obj {string} headers {string} token {string}, saveAs {string}")
    public void sendRequestJsonObject(String requestType, String apiPath, String objectContextVarName,
                                      String headersVar, String token, String saveAsVar){
        try {
            ApiPaths apiPaths = new ApiPaths();
            Field declaredField = apiPaths.getClass().getDeclaredField(apiPath);
            apiPath = String.valueOf(declaredField.get(apiPaths));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        RestHandler.RequestType requestTypeEnum = null;
        if(requestType.toLowerCase(Locale.ROOT).contains("put")){
            requestTypeEnum = RestHandler.RequestType.PUT;
        }
        if(requestType.toLowerCase(Locale.ROOT).contains("post")){
            requestTypeEnum = RestHandler.RequestType.POST;
        }
        if(requestType.toLowerCase(Locale.ROOT).contains("get")){
            requestTypeEnum = RestHandler.RequestType.GET;
        }
        if(requestType.toLowerCase(Locale.ROOT).contains("delete")){
            requestTypeEnum = RestHandler.RequestType.DELETE;
        }
        Assert.assertNotNull("Request type not recognized " + requestType, requestTypeEnum);

        String[] headers = (String[]) getSavedContextVarIfExist(headersVar, true);
        String newHeaders[] = new String[headers.length + 2];
        for (int i = 0; i < headers.length; i++) newHeaders[i] = headers[i];
        newHeaders[newHeaders.length - 2] = "Authorization";
        newHeaders[newHeaders.length - 1] =
                String.valueOf(getSavedContextVarIfExist(token, true));
        Object objToSend = getSavedContextVarIfExist(
                objectContextVarName, true);
        Response response = restHandler.sendRequestViaJson(requestTypeEnum, apiPath, objToSend, newHeaders
        );
        saveToScenarioContext(saveAsVar, response);
    }

    private void updateObjectAndSetData(String objectContextVarName, ArrayList<String> fieldsName,
                                       ArrayList<String>  fieldsValue) {
        Assert.assertEquals(fieldsName.size(), fieldsValue.size());
        Object objectFromContext =
                getSavedContextVarIfExist(objectContextVarName, true);
        for(int i = 0; i < fieldsName.size(); i++){
            Field typeOfField;
            String fieldName = fieldsName.get(i);
            String fieldValue = fieldsValue.get(i);
            try {
                typeOfField = objectFromContext.getClass().getDeclaredField(fieldName);
            } catch (NoSuchFieldException e) {
                throw new RuntimeException(e);
            }
            String setterMethodName = makeSetterName(fieldName);

            Long fieldValueAsLong = null;
            Integer fieldValueAsInteger = null;
            Double fieldValueAsDouble = null;

            if(typeOfField.getType().equals(Long.class)){
                fieldValueAsLong = Long.parseLong(fieldValue);
            }
            if(typeOfField.getType().equals(Integer.class)){
                fieldValueAsInteger = Integer.parseInt(fieldValue);
            }
            if(typeOfField.getType().equals(Double.class)){
                fieldValueAsDouble = Double.parseDouble(fieldValue);
            }
            if (fieldValueAsLong != null) {
                invokeMethodFromObject(
                        objectFromContext, setterMethodName, fieldValueAsLong);
            }
            else if (fieldValueAsInteger != null) {
                invokeMethodFromObject(
                        objectFromContext, setterMethodName, fieldValueAsInteger);
            }
            else if (fieldValueAsDouble != null) {
                invokeMethodFromObject(
                        objectFromContext, setterMethodName, fieldValueAsDouble);
            }
            else {
                invokeMethodFromObject(objectFromContext, setterMethodName, fieldValue);
            }
        }
        saveToScenarioContext(objectContextVarName, objectFromContext);
    }

    /**
     * @param rawVar    raw variable convert from
     * @param modelName you can define model name by FULL path
     *                  (example: com.testFramework.appCapital.AuthResponse) or just mention model name (example:
     *                  AuthResponse), in this case method will find model in project.
     * @param saveAsVar save converted variable in scenario context by this name
     */
    @Then("Convert RAW var {string} to model {string} and save as {string}")
    public void convertRawVariableToModel(String rawVar, String modelName, String saveAsVar) {
        Object rawVarObject = getSavedContextVarIfExist(rawVar, true);
        if (rawVarObject instanceof Response) {
            Response tmpResponse = (Response) rawVarObject;
            Object objectToStore = null;
            if (modelName.contains(".") && modelName.contains("com")) { // full path check
                try {
                    objectToStore = tmpResponse.as(Class.forName(modelName));
                    saveToScenarioContext(saveAsVar, objectToStore);
                    return;
                } catch (ClassNotFoundException e) {
                    Assert.fail("Model name: " + modelName + " not found by full class path. " + e);
                }
            }
            try {
                String className = searchClassNameInProject(modelName);
                Class<?> classToConvert = Class.forName(className);
                objectToStore = tmpResponse.as(classToConvert);
            } catch (Exception e) {
                Assert.fail("\nCant convert: " + rawVar + " for model name: " + modelName + " || Seems model class is "
                        + "corrupted. || Full error:\n\n " + e);
            }
            if (objectToStore == null) {
                Assert.fail("Can't convert RAW " + rawVar + " to model " + modelName
                        + " in package com.testFramework! There is no such model.");
            } else {
                saveToScenarioContext(saveAsVar, objectToStore);
            }
            System.out.println(); // for debug
        }
    }

    /**
     * @param contextVarName  stored variable in local scenario context
     * @param modelFieldName  field in model, if model have nested objects, must be separated with dot.
     *                        Example: data.object1.object2
     * @param modelFieldValue field value. String type. But can contain integer or double values.
     *                        Can contain comparison signs: > , < , = , !=, contains-> , amount - number of result objects.
     *                        (saved) can extract another variable from scenario context. No SPACES ALLOWED for
     *                        arithmetic comparison operations!
     *                        For example >1, =0, !=200, amount>200, =email_l, >value_g, contains->value
     */
    @Then("Assert {string} field {string} {string}")
    public void assertModelFields(String contextVarName, String modelFieldName, String modelFieldValue) {
        Assert.assertFalse("There are spaces detected in model field value! No spaces allowed," +
                        " for arithmetic comparison operations check help for method. Value to check:\n" + modelFieldValue,
                modelFieldValue.contains("!= ") || modelFieldValue.contains(" !=") ||
                        modelFieldValue.contains("> ") || modelFieldValue.contains(" >") ||
                        modelFieldValue.contains("< ") || modelFieldValue.contains(" <") ||
                        modelFieldValue.contains("amount ") || modelFieldValue.contains(" amount") ||
                        modelFieldValue.contains("= ") || modelFieldValue.contains(" ="));

        String cleanModelFieldValue = modelFieldValue.replace("!=", "")
                .replace("contains->", "").replace(">", "")
                .replace("<", "").replace("=", "")
                .replace("amount", "");
        if (modelFieldValue.endsWith("_g")) {
            cleanModelFieldValue = String.valueOf(
                    getSavedContextVarIfExist(cleanModelFieldValue, true));
        }
        if (modelFieldValue.endsWith("_l")) {
            cleanModelFieldValue = String.valueOf(
                    getSavedContextVarIfExist(cleanModelFieldValue, true));
        }
        if (!modelFieldValue.toLowerCase(Locale.ROOT).contains("null")) {
            Assert.assertNotEquals("Null value found in context, but it was defined as saved before: "
                    + modelFieldValue, "null", cleanModelFieldValue);
        }

        modelFieldValue = modelFieldValue.contains("contains->") ?
                modelFieldValue.substring(0, 10) + cleanModelFieldValue : modelFieldValue;
        modelFieldValue = modelFieldValue.contains("amount") ? modelFieldValue.substring(0, 7)
                + cleanModelFieldValue : modelFieldValue;
        modelFieldValue =
                modelFieldValue.substring(0, 1).contains("=") ||
                        modelFieldValue.substring(0, 1).contains(">") ||
                        modelFieldValue.substring(0, 1).contains("<") ?
                        modelFieldValue.charAt(0) + cleanModelFieldValue : modelFieldValue;

        modelFieldValue = modelFieldValue.substring(0, 2).contains("!=") ?
                modelFieldValue.substring(0, 2) + cleanModelFieldValue : modelFieldValue;

        Object contextVarObject = getSavedScenarioContextVar(contextVarName);
        ArrayList<String> innerObjectGetMethods = parseModelFieldNameToGetters(modelFieldName);

        Object innerObject = invokeLastMethodFromModel
                (innerObjectGetMethods, modelFieldName, contextVarObject);

        String valueInObjectStr;
        if (modelFieldValue.contains("amount") && innerObject instanceof ArrayList) {
            valueInObjectStr = String.valueOf(((ArrayList<?>) innerObject).size());
            modelFieldValue = modelFieldValue.replace("amount", "")
                    .replace(" ", "");
        } else {
            valueInObjectStr = String.valueOf(innerObject);
        }
        if (modelFieldValue.substring(0, 1).contains(">") || modelFieldValue.substring(0, 1).contains("<")) {
            int valueInObjectInt;
            double valueInObjectDouble;

            if (modelFieldValue.contains(".") || modelFieldValue.contains(",")) {
                valueInObjectDouble = Double.parseDouble(valueInObjectStr);

                if (modelFieldValue.contains(">")) {
                    Assert.assertTrue("\n\nObjActualValue: " + valueInObjectStr + " || RequestedField: " + modelFieldName
                                    + " || ScenarioContextObj: " + contextVarName + "\n\n Not bigger then " +
                                    modelFieldValue.replace(">", "") +
                                    "\n\nClass name: " + contextVarObject.getClass() +
                                    "\n\nFull object: " + contextVarObject + "\n",
                            valueInObjectDouble >
                                    Double.parseDouble(modelFieldValue.replace(">", "")));
                }
                if (modelFieldValue.contains("<")) {
                    Assert.assertTrue("\n\nObjActualValue: " + valueInObjectStr + " || RequestedField: " + modelFieldName
                                    + " || ScenarioContextObj: " + contextVarName + "\n\n Not less then " +
                                    modelFieldValue.replace("<", "") +
                                    "\n\nClass name: " + contextVarObject.getClass() +
                                    "\n\nFull object: " + contextVarObject + "\n",
                            valueInObjectDouble <
                                    Double.parseDouble(modelFieldValue.replace("<", "")));
                }
            } else {
                valueInObjectInt = Integer.parseInt(valueInObjectStr);
                if (modelFieldValue.contains(">")) {
                    Assert.assertTrue("\n\nObjActualValue: " + valueInObjectStr + " || RequestedField: " + modelFieldName
                                    + " || ScenarioContextObj: " + contextVarName + "\n\nNot bigger then " +
                                    modelFieldValue.replace(">", "") +
                                    "\n\nClass name: " + contextVarObject.getClass() +
                                    "\n\nFull object: " + contextVarObject + "\n",
                            valueInObjectInt >
                                    Integer.parseInt(modelFieldValue.replace(">", "")));
                }
                if (modelFieldValue.contains("<")) {
                    Assert.assertTrue("\n\nObjActualValue: " + valueInObjectStr + " || RequestedField: " + modelFieldName
                                    + " || ScenarioContextObj: " + contextVarName + "\n\nNot less then "
                                    + modelFieldValue.replace("<", "") +
                                    "\n\nClass name: " + contextVarObject.getClass() +
                                    "\n\nFull object: " + contextVarObject + "\n",
                            valueInObjectInt <
                                    Integer.parseInt(modelFieldValue.replace("<", "")));
                }
            }
            return;
        }
        if (modelFieldValue.contains("contains->")) {
            Assert.assertTrue("\n\nObjActualValue: " + valueInObjectStr + " || RequestedField: " + modelFieldName
                            + " || ScenarioContextObj: " + contextVarName + "\n\n Not contains " +
                            modelFieldValue.replace("contains->", "") +
                            "\n\nClass name: " + contextVarObject.getClass() +
                            "\n\nFull object: " + contextVarObject + "\n",
                    valueInObjectStr.contains(modelFieldValue.replace("contains->", "")));
            return;
        }
        if (modelFieldValue.substring(0, 1).contains("=")) {
            Assert.assertEquals("\n\nObjActualValue: " + valueInObjectStr + " || RequestedField: " + modelFieldName
                            + " || ScenarioContextObj: " + contextVarName + "\n\nNot equals to " +
                            modelFieldValue.replace("=", "") +
                            "\n\nClass name: " + contextVarObject.getClass() +
                            "\n\nFull object: " + contextVarObject + "\n",
                    modelFieldValue.replace("=", ""), valueInObjectStr);
            return;
        }
        if (modelFieldValue.substring(0, 2).contains("!=")) {
            Assert.assertNotEquals("\n\nObjActualValue: " + valueInObjectStr + " || RequestedField: " + modelFieldName
                            + " || ScenarioContextObj: " + contextVarName + "\n\nNot equals to " +
                            modelFieldValue.replace("!=", "") +
                            "\n\nClass name: " + contextVarObject.getClass() +
                            "\n\nFull object: " + contextVarObject + "\n",
                    modelFieldValue.replace("!=", ""), valueInObjectStr);
            return;
        }
        Assert.fail("No comparison symbols was found for value " + modelFieldValue + " check help for method." +
                "\n\nCan contain comparison signs: > , < , = , !=, contains-> , amount - number of result objects." +
                "\n(saved) can extract another variable from scenario context." +
                "\nFor example >1, =0, !=200, amount>200, =email(saved), >value(saved), contains->value");
    }

    private Object invokeLastMethodFromModel(ArrayList<String> innerObjectGetMethods,
                                             String modelFieldName, Object contextVarObject) {
        Object innerObject = null;
        for (int i = 0; i < innerObjectGetMethods.size(); i++) {
            Object tmpObjectToInvoke = innerObject == null ? contextVarObject : innerObject;
            String methodName = innerObjectGetMethods.get(i);
            Object methodArgs = null;
            if (methodName.contains("(") && methodName.contains(")") &&
                    tmpObjectToInvoke instanceof ArrayList && methodName.contains("get")) {

                String parameter = methodName.substring
                        (methodName.indexOf("(") + 1, methodName.indexOf(")"));
                Assert.assertNotEquals("Index of inner element can't be 0, must start from 1. For field:" +
                        modelFieldName, "0", parameter);
                parameter = String.valueOf(Integer.parseInt(parameter) - 1);

                if (parameter.chars().allMatch(Character::isDigit)) {
                    methodArgs = Integer.valueOf(parameter);
                }
            }
            if (methodArgs == null) {
                innerObject = invokeMethodFromObject(tmpObjectToInvoke, methodName);
            } else {
                methodName = methodName.substring(0, methodName.indexOf("("));
                innerObject = invokeMethodFromObject(tmpObjectToInvoke, methodName, methodArgs);
            }
        }
        return innerObject;
    }

    @Then("Get value from object field {string} in {string} and save as {string}")
    public void getModelFieldValueAndSaveAs(String modelFieldName, String contextVarName, String saveAsVar) {
        Object contextVarObject = getSavedContextVarIfExist(contextVarName, true);
        ArrayList<String> innerObjectGetMethods = parseModelFieldNameToGetters(modelFieldName);
        Object object = invokeLastMethodFromModel(innerObjectGetMethods, modelFieldName, contextVarObject);
        saveToScenarioContext(saveAsVar, object);
    }
}
