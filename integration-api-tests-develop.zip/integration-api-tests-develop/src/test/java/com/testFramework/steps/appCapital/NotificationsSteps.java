package com.testFramework.steps.appCapital;

import com.testFramework.appCapital.ApiPaths;
import com.testFramework.appCapital.Constants;
import com.testFramework.appCapital.models.apiNotifications.SendFeedbackEmailReq;
import com.testFramework.core.RestHandler;
import com.testFramework.core.TempMailHandler;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.restassured.response.Response;

import static com.testFramework.core.RestHandler.RequestType.POST;

public class NotificationsSteps {
    Scenario scenario;

    @Before
    public void before(Scenario scenario) {
        this.scenario = this.scenario == null ? scenario : this.scenario;
        this.baseSteps = this.baseSteps == null ? new BaseSteps(scenario) : this.baseSteps;
    }

    private final RestHandler restHandler = new RestHandler();
    private final ApiPaths apiPaths = new ApiPaths();
    private final Constants constants = new Constants();
    private final TempMailHandler tempMailHandler = new TempMailHandler();
    private BaseSteps baseSteps;

    @Given("SendFeedback: email {string} message {string} appName {string}, save as {string}")
    public void sendFeedbackEmail(String email, String message, String appName, String saveAsVarName) {
        SendFeedbackEmailReq request = new SendFeedbackEmailReq();
        if(email.endsWith("_g") || email.endsWith("_l")){
            request.setFrom(String.valueOf(
                    baseSteps.getSavedContextVarIfExist(email, true)));
        }
        else {
            request.setFrom(email);
        }
        if(message.endsWith("_g") || message.endsWith("_l")){
            request.setMessage(String.valueOf(
                    baseSteps.getSavedContextVarIfExist(message, true)));
        }
        else {
            request.setMessage(message);
        }
        if(appName.endsWith("_g") || appName.endsWith("_l")){
            request.setApplication(String.valueOf(
                    baseSteps.getSavedContextVarIfExist(appName, true)));
        }
        else {
            request.setApplication(appName);
        }
        Response response = restHandler.sendRequestViaJson(POST,
                apiPaths.notifFeedbackEmail, request);
        baseSteps.saveToScenarioContext(saveAsVarName, response);
    }
}
