package com.testFramework.steps.appCapital;

import com.testFramework.appCapital.ApiPaths;
import com.testFramework.appCapital.Constants;
import com.testFramework.appCapital.models.apiApplications.createApp.ApplicationsCreateAppUsrReq;
import com.testFramework.core.RestHandler;
import com.testFramework.core.TempMailHandler;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;

import static com.testFramework.core.RestHandler.RequestType.GET;
import static com.testFramework.core.RestHandler.RequestType.POST;

public class ApplicationsSteps {
    Scenario scenario;

    @Before
    public void before(Scenario scenario) {
        this.scenario = this.scenario == null ? scenario : this.scenario;
        this.baseSteps = this.baseSteps == null ? new BaseSteps(scenario) : this.baseSteps;
    }

    private final RestHandler restHandler = new RestHandler();
    private final ApiPaths apiPaths = new ApiPaths();
    private final Constants constants = new Constants();
    private BaseSteps baseSteps;

    @Then("GetAppList: token {string} page {int} pageSize {int}, saveAs {string}")
    public void getAppList(String token, int page, int pageSize, String saveAsVarName){
        String apiPath = "/?page=" + page + "&pagesize=" + pageSize;
        baseSteps.saveToScenarioContext(saveAsVarName,
                restHandler.sendRequestWithHeadersAndParams(GET,
                        apiPaths.appsCreateAppAdm + apiPath, new String[]{
                                "Authorization", String.valueOf(baseSteps.getSavedContextVarIfExist(
                                        token, true)),
                                "Api-Key", constants.apiKey
                        }, new String[]{})
                );
    }

    @Then("CreateAppByUser, token {string}, appName {string} platform {string} organizationId {string} bundleId {string}, saveAs {string}")
    public void createApplicationUsrRequestAndSaveAs(String tokenVar, String appName, String platform,
                                                     String organizationId, String bundleId, String saveAsVarName) {
        ApplicationsCreateAppUsrReq request = new ApplicationsCreateAppUsrReq();
        if(appName.endsWith("_g") || appName.endsWith("_l")){
            request.setName(String.valueOf(
                    baseSteps.getSavedContextVarIfExist(appName, true)));
        }
        else {
            request.setName(appName);
        }
        if(platform.endsWith("_g") || platform.endsWith("_l")){
            request.setPlatform(String.valueOf(
                    baseSteps.getSavedContextVarIfExist(platform, true)));
        }
        else {
            request.setPlatform(platform);
        }
        if(organizationId.endsWith("_g") || organizationId.endsWith("_l")){
            request.setOrganizationId(Long.valueOf(String.valueOf(
                    baseSteps.getSavedContextVarIfExist(organizationId, true))));
        }
        else {
            request.setOrganizationId(Long.valueOf(organizationId));
        }
        if(bundleId.endsWith("_g") || bundleId.endsWith("_l")){
            request.setBundleId(String.valueOf(
                    baseSteps.getSavedContextVarIfExist(bundleId, true)));
        }
        else {
            request.setBundleId(bundleId);
        }
        Response response = restHandler.sendRequestViaJson
                (POST, apiPaths.appsCreateAppUsr, request,
                        "Authorization", String.valueOf((baseSteps.getSavedContextVarIfExist
                                (tokenVar, true))),
                        "Accept-Charset", "UTF-8", "Accept-Language", "en");
        baseSteps.saveToScenarioContext(saveAsVarName, response);
    }
}
