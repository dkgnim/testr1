
package com.testFramework.appCapital.models.apiApplications.getAppList;

import javax.annotation.Generated;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("net.hexar.json2pojo")
@JsonIgnoreProperties(ignoreUnknown = true)
@SuppressWarnings("unused")
public class Datum {

    @SerializedName("adapty_basic_auth_key")
    private String adaptyBasicAuthKey;
    @SerializedName("adapty_project_name")
    private String adaptyProjectName;
    @SerializedName("api_key")
    private String apiKey;
    @SerializedName("bundle_id")
    private String bundleId;
    @SerializedName("created_at")
    private String createdAt;
    @SerializedName("current_recommended_version")
    private String currentRecommendedVersion;
    @SerializedName("domain_name")
    private String domainName;
    @SerializedName("firebase_api_secret")
    private String firebaseApiSecret;
    @SerializedName("firebase_app_id")
    private String firebaseAppId;
    @SerializedName("firebase_project_name")
    private String firebaseProjectName;
    @Expose
    private Long id;
    @SerializedName("minimal_support_version")
    private String minimalSupportVersion;
    @Expose
    private String name;
    @SerializedName("organization_id")
    private String organizationId;
    @SerializedName("package_name")
    private String packageName;
    @Expose
    private String platform;
    @SerializedName("support_email")
    private String supportEmail;
    @SerializedName("updated_at")
    private String updatedAt;

    public String getAdaptyBasicAuthKey() {
        return adaptyBasicAuthKey;
    }

    public void setAdaptyBasicAuthKey(String adaptyBasicAuthKey) {
        this.adaptyBasicAuthKey = adaptyBasicAuthKey;
    }

    public String getAdaptyProjectName() {
        return adaptyProjectName;
    }

    public void setAdaptyProjectName(String adaptyProjectName) {
        this.adaptyProjectName = adaptyProjectName;
    }

    public String getApiKey() {
        return apiKey;
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }

    public String getBundleId() {
        return bundleId;
    }

    public void setBundleId(String bundleId) {
        this.bundleId = bundleId;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getCurrentRecommendedVersion() {
        return currentRecommendedVersion;
    }

    public void setCurrentRecommendedVersion(String currentRecommendedVersion) {
        this.currentRecommendedVersion = currentRecommendedVersion;
    }

    public String getDomainName() {
        return domainName;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    public String getFirebaseApiSecret() {
        return firebaseApiSecret;
    }

    public void setFirebaseApiSecret(String firebaseApiSecret) {
        this.firebaseApiSecret = firebaseApiSecret;
    }

    public String getFirebaseAppId() {
        return firebaseAppId;
    }

    public void setFirebaseAppId(String firebaseAppId) {
        this.firebaseAppId = firebaseAppId;
    }

    public String getFirebaseProjectName() {
        return firebaseProjectName;
    }

    public void setFirebaseProjectName(String firebaseProjectName) {
        this.firebaseProjectName = firebaseProjectName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMinimalSupportVersion() {
        return minimalSupportVersion;
    }

    public void setMinimalSupportVersion(String minimalSupportVersion) {
        this.minimalSupportVersion = minimalSupportVersion;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(String organizationId) {
        this.organizationId = organizationId;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String getSupportEmail() {
        return supportEmail;
    }

    public void setSupportEmail(String supportEmail) {
        this.supportEmail = supportEmail;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

}
