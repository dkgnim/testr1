
package com.testFramework.appCapital.models.apiAccounts.getAccountsList.getDeletedAccount;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class AccountsGetDeletedAccountResp {

    @Expose
    private Long code;
    @Expose
    private Object debug;
    @Expose
    private String message;
    @Expose
    private String service;
    @Expose
    private String timestamp;

    public Long getCode() {
        return code;
    }

    public void setCode(Long code) {
        this.code = code;
    }

    public Object getDebug() {
        return debug;
    }

    public void setDebug(Object debug) {
        this.debug = debug;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return "AccountsGetDeletedAccountResp{" +
                "code=" + code +
                ", debug=" + debug +
                ", message='" + message + '\'' +
                ", service='" + service + '\'' +
                ", timestamp='" + timestamp + '\'' +
                '}';
    }
}
