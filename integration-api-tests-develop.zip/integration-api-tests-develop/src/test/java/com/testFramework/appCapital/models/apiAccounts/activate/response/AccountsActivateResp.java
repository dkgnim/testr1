
package com.testFramework.appCapital.models.apiAccounts.activate.response;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class AccountsActivateResp {

    @Override
    public String toString() {
        return "AccountsActivateResp{" +
                "password='" + password + '\'' +
                ", tokens=" + tokens +
                '}';
    }

    @Expose
    private String password;
    @Expose
    private Tokens tokens;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Tokens getTokens() {
        return tokens;
    }

    public void setTokens(Tokens tokens) {
        this.tokens = tokens;
    }

}
