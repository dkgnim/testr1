
package com.testFramework.appCapital.models.apiAccounts.getMyAccount;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class AccountsSingleAccountResp {

    @Expose
    private String createdAt;
    @Expose
    private Object createdBy;
    @Expose
    private Object deletedAt;
    @Expose
    private Object deletedBy;
    @Expose
    private String email;
    @Expose
    private Boolean emailVerified;
    @Expose
    private String firstName;
    @Expose
    private Long id;
    @Expose
    private Boolean isAdmin;
    @Expose
    private Boolean isDeleted;
    @Expose
    private Boolean isLocked;
    @Expose
    private String lastName;
    @Expose
    private String updatedAt;
    @Expose
    private Long updatedBy;

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public Object getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Object createdBy) {
        this.createdBy = createdBy;
    }

    public Object getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(Object deletedAt) {
        this.deletedAt = deletedAt;
    }

    public Object getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(Object deletedBy) {
        this.deletedBy = deletedBy;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Boolean getEmailVerified() {
        return emailVerified;
    }

    public void setEmailVerified(Boolean emailVerified) {
        this.emailVerified = emailVerified;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Boolean getIsAdmin() {
        return isAdmin;
    }

    public void setIsAdmin(Boolean isAdmin) {
        this.isAdmin = isAdmin;
    }

    public Boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Boolean getIsLocked() {
        return isLocked;
    }

    public void setIsLocked(Boolean isLocked) {
        this.isLocked = isLocked;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Long getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(Long updatedBy) {
        this.updatedBy = updatedBy;
    }

    @Override
    public String toString() {
        return "AccountsSingleAccountResp{" +
                "createdAt='" + createdAt + '\'' +
                ", createdBy=" + createdBy +
                ", deletedAt=" + deletedAt +
                ", deletedBy=" + deletedBy +
                ", email='" + email + '\'' +
                ", emailVerified=" + emailVerified +
                ", firstName='" + firstName + '\'' +
                ", id=" + id +
                ", isAdmin=" + isAdmin +
                ", isDeleted=" + isDeleted +
                ", isLocked=" + isLocked +
                ", lastName='" + lastName + '\'' +
                ", updatedAt='" + updatedAt + '\'' +
                ", updatedBy=" + updatedBy +
                '}';
    }
}
