
package com.testFramework.appCapital.models.apiAccounts.changePassword;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class AccountsChangePassAdmReq {

    @Expose
    private String password;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "AccountsChangePassAdmReq{" +
                "password='" + password + '\'' +
                '}';
    }
}
