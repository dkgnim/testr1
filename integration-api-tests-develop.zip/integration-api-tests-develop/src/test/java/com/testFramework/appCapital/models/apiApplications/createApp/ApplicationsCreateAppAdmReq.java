
package com.testFramework.appCapital.models.apiApplications.createApp;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class ApplicationsCreateAppAdmReq {

    @Expose
    private String adaptyBasicAuthKey;
    @Expose
    private String adaptyProjectName;
    @Expose
    private String bundleId;
    @Expose
    private String currentRecommendedVersion;
    @Expose
    private String firebaseApiSecret;
    @Expose
    private String firebaseAppId;
    @Expose
    private String firebaseProjectName;
    @Expose
    private String minimalSupportVersion;
    @Expose
    private String name;
    @Expose
    private Long organizationId;
    @Expose
    private String platform;
    @Expose
    private String supportEmail;

    public String getAdaptyBasicAuthKey() {
        return adaptyBasicAuthKey;
    }

    public void setAdaptyBasicAuthKey(String adaptyBasicAuthKey) {
        this.adaptyBasicAuthKey = adaptyBasicAuthKey;
    }

    public String getAdaptyProjectName() {
        return adaptyProjectName;
    }

    public void setAdaptyProjectName(String adaptyProjectName) {
        this.adaptyProjectName = adaptyProjectName;
    }

    public String getBundleId() {
        return bundleId;
    }

    public void setBundleId(String bundleId) {
        this.bundleId = bundleId;
    }

    public String getCurrentRecommendedVersion() {
        return currentRecommendedVersion;
    }

    public void setCurrentRecommendedVersion(String currentRecommendedVersion) {
        this.currentRecommendedVersion = currentRecommendedVersion;
    }

    public String getFirebaseApiSecret() {
        return firebaseApiSecret;
    }

    public void setFirebaseApiSecret(String firebaseApiSecret) {
        this.firebaseApiSecret = firebaseApiSecret;
    }

    public String getFirebaseAppId() {
        return firebaseAppId;
    }

    public void setFirebaseAppId(String firebaseAppId) {
        this.firebaseAppId = firebaseAppId;
    }

    public String getFirebaseProjectName() {
        return firebaseProjectName;
    }

    public void setFirebaseProjectName(String firebaseProjectName) {
        this.firebaseProjectName = firebaseProjectName;
    }

    public String getMinimalSupportVersion() {
        return minimalSupportVersion;
    }

    public void setMinimalSupportVersion(String minimalSupportVersion) {
        this.minimalSupportVersion = minimalSupportVersion;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Long organizationId) {
        this.organizationId = organizationId;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String getSupportEmail() {
        return supportEmail;
    }

    public void setSupportEmail(String supportEmail) {
        this.supportEmail = supportEmail;
    }

    @Override
    public String toString() {
        return "ApplicationsCreateAppAdmReq{" +
                "adaptyBasicAuthKey='" + adaptyBasicAuthKey + '\'' +
                ", adaptyProjectName='" + adaptyProjectName + '\'' +
                ", bundleId='" + bundleId + '\'' +
                ", currentRecommendedVersion='" + currentRecommendedVersion + '\'' +
                ", firebaseApiSecret='" + firebaseApiSecret + '\'' +
                ", firebaseAppId='" + firebaseAppId + '\'' +
                ", firebaseProjectName='" + firebaseProjectName + '\'' +
                ", minimalSupportVersion='" + minimalSupportVersion + '\'' +
                ", name='" + name + '\'' +
                ", organizationId=" + organizationId +
                ", platform='" + platform + '\'' +
                ", supportEmail='" + supportEmail + '\'' +
                '}';
    }
}
