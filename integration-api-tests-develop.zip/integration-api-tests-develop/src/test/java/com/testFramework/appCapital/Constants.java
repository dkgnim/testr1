package com.testFramework.appCapital;

import com.testFramework.core.RunMode;

import java.util.Locale;

public class Constants {
    public String emailAdmin, passwordAdmin, emailUser, passwordUser, apiKey;
    public int socketTimeout, connectionTimeout;

    public Constants() {
        if (System.getProperty(RunMode.class.getSimpleName()).equals(RunMode.PROD.name())) {
            emailUser = "qa+46@appcapital.vc";
            apiKey = "y6Jg54mMFUGtwdd9hm";
            passwordUser = "xaoO1uLyxliY";
            emailAdmin = "qa+55@appcapital.vc";
            passwordAdmin = "Test!123";
            socketTimeout = 20000;
            connectionTimeout = 20000;
        }
    }

    public String getEmail(String userRole){
        if(userRole.toLowerCase(Locale.ROOT).contains("user")){
            return emailUser;
        }
        if(userRole.toLowerCase(Locale.ROOT).contains("admin")){
            return emailAdmin;
        }
        return "";
    }

    public String getPassword(String userRole){
        if(userRole.toLowerCase(Locale.ROOT).contains("user")){
            return passwordUser;
        }
        if(userRole.toLowerCase(Locale.ROOT).contains("admin")){
            return passwordAdmin;
        }
        return "";
    }
}
