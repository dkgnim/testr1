
package com.testFramework.appCapital.models.apiApplications.getAppList;

import java.util.List;
import javax.annotation.Generated;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.annotations.Expose;

@Generated("net.hexar.json2pojo")
@JsonIgnoreProperties(ignoreUnknown = true)
@SuppressWarnings("unused")
public class ApplicationsGetAppListResp {

    @Expose
    private List<Datum> data;

    public List<Datum> getData() {
        return data;
    }

    public void setData(List<Datum> data) {
        this.data = data;
    }

}
