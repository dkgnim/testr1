
package com.testFramework.appCapital.models.apiAccounts.changePassword;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class AccountsChangePassNoAuthWithCodeUsrReq {

    @Expose
    private String code;
    @Expose
    private String password;
    @Expose
    private String passwordRetype;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPasswordRetype() {
        return passwordRetype;
    }

    public void setPasswordRetype(String passwordRetype) {
        this.passwordRetype = passwordRetype;
    }

    @Override
    public String toString() {
        return "AccountsChangePassNoAuthWithCodeReq{" +
                "code='" + code + '\'' +
                ", password='" + password + '\'' +
                ", passwordRetype='" + passwordRetype + '\'' +
                '}';
    }
}
