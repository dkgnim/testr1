
package com.testFramework.appCapital.models.apiAccounts.getAccountsList.getAccountsList;

import java.util.List;
import javax.annotation.Generated;
import com.google.gson.annotations.Expose;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class AccountsGetAccountsList {

    @Expose
    private List<Datum> data;
    @Expose
    private Paging paging;

    public List<Datum> getData() {
        return data;
    }

    public void setData(List<Datum> data) {
        this.data = data;
    }

    public Paging getPaging() {
        return paging;
    }

    public void setPaging(Paging paging) {
        this.paging = paging;
    }

    @Override
    public String toString() {
        return "AccountsGetAccountsList{" +
                "data=" + data +
                ", paging=" + paging +
                '}';
    }
}
