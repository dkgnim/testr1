
package com.testFramework.appCapital.models.apiAccounts.deleteAccount;

import java.util.List;
import javax.annotation.Generated;
import com.google.gson.annotations.Expose;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class AccountsDeleteAccount {

    @Expose
    private Data data;
    @Expose
    private List<Object> error;
    @Expose
    private Boolean success;

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public List<Object> getError() {
        return error;
    }

    public void setError(List<Object> error) {
        this.error = error;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    @Override
    public String toString() {
        return "AccountsDeleteAccount{" +
                "data=" + data +
                ", error=" + error +
                ", success=" + success +
                '}';
    }
}
