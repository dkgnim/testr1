package com.testFramework.appCapital;

import com.testFramework.core.PropertyHandler;

import java.util.Locale;

public class ApiPaths {

    public String basePath;

    public String accSignIn, accSignInRefresh, accSignOut, accGetMyAccount, accAccountsAdmin,
            accAccountsUser, accEmailActivate, accChangePassNoAuthUsr, accChangePassAuthUsr,
            accChangePassAdm;

    public String notifFeedbackEmail;

    public String appsCreateAppUsr, appsCreateAppAdm;

    public ApiPaths() {
        PropertyHandler propertyHandler = new PropertyHandler();
        if (propertyHandler.getProperty("runMode").toLowerCase(Locale.ROOT).equals("production")) {
            basePath = "https://api.appcapital.vc";
        }
        accSignIn = basePath + "/accounts/signin";
        accSignOut = basePath + "/accounts/me/signout";
        accSignInRefresh = basePath + "/accounts/signin/refresh";
        accGetMyAccount = basePath + "/accounts/me";
        accAccountsAdmin = basePath + "/accounts/admin";
        accAccountsUser = basePath + "/accounts";
        accEmailActivate = basePath + "/accounts/email/activate";
        accChangePassNoAuthUsr = basePath + "/accounts/password/change/code";
        accChangePassAuthUsr = basePath + "/accounts/me/password/change";
        accChangePassAdm = basePath + "/accounts/admin/";
        notifFeedbackEmail = basePath + "/notifications/feedback/email/";
        appsCreateAppUsr = basePath + "/applications/";
        appsCreateAppAdm = basePath + "/applications/admin/";
    }
}
