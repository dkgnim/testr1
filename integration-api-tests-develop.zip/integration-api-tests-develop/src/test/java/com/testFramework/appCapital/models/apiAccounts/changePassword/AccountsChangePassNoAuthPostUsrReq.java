
package com.testFramework.appCapital.models.apiAccounts.changePassword;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class AccountsChangePassNoAuthPostUsrReq {

    @Expose
    private String email;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "AccountsChangePassReq{" +
                "email='" + email + '\'' +
                '}';
    }
}
