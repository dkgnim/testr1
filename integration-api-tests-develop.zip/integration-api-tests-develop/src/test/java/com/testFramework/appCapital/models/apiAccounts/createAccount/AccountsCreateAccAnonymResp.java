
package com.testFramework.appCapital.models.apiAccounts.createAccount;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class AccountsCreateAccAnonymResp {

    @SerializedName("email")
    private String email;
    @SerializedName("emailVerified")
    private Boolean emailVerified;
    @SerializedName("firstName")
    private String firstName;
    @SerializedName("id")
    private Long id;
    @SerializedName("isAdmin")
    private Boolean isAdmin;
    @SerializedName("isLocked")
    private Boolean isLocked;
    @SerializedName("lastName")
    private String lastName;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Boolean getEmailVerified() {
        return emailVerified;
    }

    public void setEmailVerified(Boolean emailVerified) {
        this.emailVerified = emailVerified;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Boolean getIsAdmin() {
        return isAdmin;
    }

    public void setIsAdmin(Boolean isAdmin) {
        this.isAdmin = isAdmin;
    }

    public Boolean getIsLocked() {
        return isLocked;
    }

    public void setIsLocked(Boolean isLocked) {
        this.isLocked = isLocked;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Override
    public String toString() {
        return "AccountsCreateAccAnonymReq{" +
                "mEmail='" + email + '\'' +
                ", mEmailVerified=" + emailVerified +
                ", mFirstName='" + firstName + '\'' +
                ", mId=" + id +
                ", mIsAdmin=" + isAdmin +
                ", mIsLocked=" + isLocked +
                ", mLastName='" + lastName + '\'' +
                '}';
    }
}
