
package com.testFramework.appCapital.models.apiApplications.createApp;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class ApplicationsCreateAppUsrResp {

    @Expose
    private String apiKey;
    @Expose
    private String bundleId;
    @Expose
    private Object createdAt;
    @Expose
    private Object createdBy;
    @Expose
    private Object domainName;
    @Expose
    private Long id;
    @Expose
    private String name;
    @Expose
    private String organizationId;
    @Expose
    private Object packageName;
    @Expose
    private String platform;
    @Expose
    private Object updatedAt;
    @Expose
    private Object updatedBy;

    public String getApiKey() {
        return apiKey;
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }

    public String getBundleId() {
        return bundleId;
    }

    public void setBundleId(String bundleId) {
        this.bundleId = bundleId;
    }

    public Object getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Object createdAt) {
        this.createdAt = createdAt;
    }

    public Object getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Object createdBy) {
        this.createdBy = createdBy;
    }

    public Object getDomainName() {
        return domainName;
    }

    public void setDomainName(Object domainName) {
        this.domainName = domainName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(String organizationId) {
        this.organizationId = organizationId;
    }

    public Object getPackageName() {
        return packageName;
    }

    public void setPackageName(Object packageName) {
        this.packageName = packageName;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public Object getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Object updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Object getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(Object updatedBy) {
        this.updatedBy = updatedBy;
    }

    @Override
    public String toString() {
        return "ApplicationsCreateAppResp{" +
                "apiKey='" + apiKey + '\'' +
                ", bundleId='" + bundleId + '\'' +
                ", createdAt=" + createdAt +
                ", createdBy=" + createdBy +
                ", domainName=" + domainName +
                ", id=" + id +
                ", name='" + name + '\'' +
                ", organizationId='" + organizationId + '\'' +
                ", packageName=" + packageName +
                ", platform='" + platform + '\'' +
                ", updatedAt=" + updatedAt +
                ", updatedBy=" + updatedBy +
                '}';
    }
}
