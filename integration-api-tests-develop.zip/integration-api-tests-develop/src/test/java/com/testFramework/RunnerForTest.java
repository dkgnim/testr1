package com.testFramework;

import com.testFramework.core.RunMode;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = {"pretty",
                "json:target/cucumber-reports/CucumberTests.json",
                "junit:target/cucumber-reports/CucumberTests.xml",
                "html:target/cucumber-reports/index.html"},
        glue = {"com/testFramework/steps"},
        features = {"src/test/resources/tests/"},
        tags = "@Run and not @Ignore,@Bug", monochrome = true)
public class RunnerForTest {
    @BeforeClass
    public static void setupClass() {
        System.setProperty(RunMode.class.getSimpleName(), RunMode.PROD.name());
    }
}


