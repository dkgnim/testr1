package com.testFramework.core;

import org.junit.Assert;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;

public class PropertyHandler {
    public String getProperty(String propertyToGet){
        String resultPropertyVal = null, propertyValFromSystemVars = null, propertyValueFromConfigFile = null;
        Properties prop = new Properties();
        try (InputStream input = Files.newInputStream(
                Paths.get("src/test/resources/config.properties"))) {
            prop.load(input);

        } catch (IOException ex) {
            ex.printStackTrace();
        }
        int systemPropsPriority = Integer.parseInt(prop.getProperty("systemVariablesPropertiesPriority"));
        int configFilePropsPriority = Integer.parseInt(prop.getProperty("configFilePropertiesPriority"));
        if(systemPropsPriority < configFilePropsPriority){
            propertyValFromSystemVars = System.getProperty(propertyToGet);
            resultPropertyVal = propertyValFromSystemVars;
        }
        else {
            propertyValueFromConfigFile = prop.getProperty(propertyToGet);
            resultPropertyVal = propertyValueFromConfigFile;
        }
        if(resultPropertyVal != null){
            return resultPropertyVal;
        }
        if(systemPropsPriority < configFilePropsPriority){
            propertyValueFromConfigFile = prop.getProperty(propertyToGet);
            resultPropertyVal = propertyValueFromConfigFile;
        }
        else {
            propertyValFromSystemVars = System.getProperty(propertyToGet);
            resultPropertyVal = propertyValFromSystemVars;
        }
        Assert.assertNotEquals("Requested property " + propertyToGet + " was not found in system " +
                "variables and not in config file.", null, resultPropertyVal);
        return resultPropertyVal;
    }
}
