package com.testFramework.core;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.Selenide;
import org.openqa.selenium.Keys;

import static com.codeborne.selenide.Condition.exist;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$x;

public class TempMailHandler {

    public TempMailHandler() {
        Configuration.headless = true;
    }

    public String waitAndGetMail(String mailAddress, Long timeToWaitInSec) {
        Selenide.open("https://tempmail.plus/ru/");
        $x("//*[@placeholder=\"Name\"]").shouldBe(exist).click();
        for (int i = 0; i <= 15; i++) {
            $x("//*[@placeholder=\"Name\"]").sendKeys(Keys.BACK_SPACE);
        }
        $x("//*[@placeholder=\"Name\"]").val(mailAddress);
        $x("//*[@id=\"pre_copy\"]").click();
        $x("//*[@src=\"/i/mail-new.svg\"]")
                .waitUntil(exist, timeToWaitInSec).click();
        $x("//*[@id='info']").shouldBe(exist);
        return $x("//a[contains(text(), 'Here')]").getAttribute("href");
    }

    public void bindMailAddress(String mailAddress, Long timeToWaitInSec) {
        Selenide.open("https://tempmail.plus/ru/");
        $x("//*[@placeholder=\"Name\"]").waitUntil(exist, timeToWaitInSec).click();
        for (int i = 0; i <= 15; i++) {
            $x("//*[@placeholder=\"Name\"]").sendKeys(Keys.BACK_SPACE);
        }
        $x("//*[@placeholder=\"Name\"]").val(mailAddress);
        $x("//*[@id=\"pre_copy\"]").click();
    }
}
