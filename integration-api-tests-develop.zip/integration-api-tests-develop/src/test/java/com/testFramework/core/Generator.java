package com.testFramework.core;

import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

public class Generator {

    public static String specialSymbolsString = "±!@#$%^&*()_+./,|\\[]{}\"'`~№:;?";

    public static String phoneNumber(String countryCode, String prefix, int numberLength) {
        StringBuilder finalPhoneNumber = new StringBuilder(countryCode + prefix);

        for (int i = 0; i < numberLength; i++) {
            String randomNum = String.valueOf(ThreadLocalRandom.current().nextInt(0, 9 + 1));
            finalPhoneNumber.append(randomNum);
        }
        // System.out.println("Generated phone:" + finalPhoneNumber.toString());
        return finalPhoneNumber.toString();
    }

    public static String phoneNumber(String prefix, int numberLength) {
        return phoneNumber("", prefix, numberLength);
    }

    public static String string
            (int length, boolean containsCyrillic, boolean containsLatin, boolean containsNumeric, boolean containsSpaces,
             boolean containsSpecialSymbols) {

        String ALPHA_NUMERIC_STRING = "";

        if (containsCyrillic) {
            ALPHA_NUMERIC_STRING += "абвгдежзийклмнопрстуфхцчшщэюяьйъ";
        }
        if (containsLatin) {
            ALPHA_NUMERIC_STRING += "abcdefghijklmnopqrstuvwxyz";
        }
        if (containsNumeric) {
            ALPHA_NUMERIC_STRING += "0123456789";
        }
        if (containsSpaces) {
            ALPHA_NUMERIC_STRING += " ";
        }
        if (containsSpecialSymbols) {
            ALPHA_NUMERIC_STRING += Generator.specialSymbolsString;
        }
        StringBuilder builder = new StringBuilder();
        while (length-- != 0) {
            int character = (int) (Math.random() * ALPHA_NUMERIC_STRING.length());
            builder.append(ALPHA_NUMERIC_STRING.charAt(character));
        }
        String result = builder.toString();
        return result;
    }

    public static String numericString(int length) {
        return string(length, false, false, true,
                false, false);
    }

    public static String numericStringWithoutLeadingZeroes(int length) {
        String result = string(length, false, false, true,
                false, false);
        while (result.startsWith("0")){
            result = string(length, false, false, true,
                    false, false);
        }
        return result;
    }

    public static String lettersString(int length, boolean cyrillic, boolean latin) {
        return string(length, cyrillic, latin, false,
                false, false);
    }

    public static String latinString(int length) {
        return string(length, false, true, false,
                false, false);
    }

    public static String cyrString(int length) {
        return string(length, true, false, false,
                false, false);
    }
}
