package com.testFramework.core;

public enum RunMode {
    PROD, DEV
}
