package com.testFramework.core;

import com.alibaba.fastjson.JSON;
import com.testFramework.appCapital.Constants;
import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.http.params.CoreConnectionPNames;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;

import static io.restassured.RestAssured.given;

public class RestHandler {

    RestAssuredConfig config;

    public RestHandler() {
        Constants constants = new Constants();
        config = RestAssured.config()
                .httpClient(HttpClientConfig.httpClientConfig()
                        .setParam(CoreConnectionPNames.CONNECTION_TIMEOUT,
                                constants.connectionTimeout)
                        .setParam(CoreConnectionPNames.SO_TIMEOUT,
                                constants.socketTimeout));
    }

    public Response sendRequestViaJson
            (RestHandler.RequestType requestType, String apiPath, Object object, String... headers) {
        String objectAsJsonString = JSON.toJSONString(object);
        RequestSpecification requestSpecification = requestSpecWithHeaders(given(), headers);
        requestSpecification.body(objectAsJsonString);

        Response response = null;
        if (requestType.equals(RequestType.POST)) {
            response = requestSpecification.config(config).contentType("application/json")
                    .body(objectAsJsonString).post(apiPath).then().extract().response();
        }
        if (requestType.equals(RequestType.GET)) {
            response = requestSpecification.config(config).contentType("application/json")
                    .body(objectAsJsonString).get(apiPath).then().extract().response();
        }
        if (requestType.equals(RequestType.DELETE)) {
            response = requestSpecification.config(config).contentType("application/json")
                    .body(objectAsJsonString).delete(apiPath).then().extract().response();
        }
        if (requestType.equals(RequestType.PUT)) {
            response = requestSpecification.config(config).contentType("application/json")
                    .body(objectAsJsonString).put(apiPath).then().extract().response();
        }
        return response;
    }

    /**
     * @param apiPath    path for api request
     * @param formParams amount must be even. First val - param name, Second val - param value
     */
    public Response sendRequestWithFormParamsAndBasicAuthSpec
    (RestHandler.RequestType requestType, String apiPath, String... formParams) {
        Assertions.assertEquals(0, formParams.length % 2,
                "formParams amount must be even");

        RequestSpecification requestSpecification =
                requestSpecWithFormParams(getBasicAuthRequestSpec(), formParams);
        return executeSpecificationAndGetResponse(requestType, apiPath, requestSpecification);
    }

    public Response sendRequestWithHeadersAndFormParams
            (RestHandler.RequestType requestType, String apiPath, String[] headers, String[] formParams) {
        RequestSpecification requestSpecification = requestSpecWithHeaders(headers);
        return executeSpecificationAndGetResponse(requestType, apiPath, requestSpecification);
    }

    public Response sendRequestWithHeadersAndParams(RestHandler.RequestType requestType,
                                                    String apiPath, String[] headers, String[] params) {
        RequestSpecification requestSpecification = requestSpecWithHeaders(headers);
        requestSpecWithParams(requestSpecification, params);
        return executeSpecificationAndGetResponse(requestType, apiPath, requestSpecification);
    }

    public Response sendRequestWithHeadersAndFormParams
            (RestHandler.RequestType requestType, String apiPath, RequestSpecification requestSpecification,
             String[] headers, String[] formParams) {

        requestSpecWithHeaders(requestSpecification, headers);
        requestSpecWithFormParams(requestSpecification, formParams);
        return executeSpecificationAndGetResponse(requestType, apiPath, requestSpecification);
    }

    public Response sendRequestWithHeadersAndFormParams(RestHandler.RequestType requestType,
                                                        String apiPath, RequestSpecification requestSpecification) {
        return sendRequestWithHeadersAndFormParams(requestType, apiPath, requestSpecification,
                new String[]{}, new String[]{});
    }

    private Response executeSpecificationAndGetResponse(RestHandler.RequestType requestType,
                                                        String apiPath, RequestSpecification requestSpecification) {
        if (requestType.equals(RequestType.POST)) {
            return requestSpecification.config(config).post(apiPath).then().extract().response();
        }
        if (requestType.equals(RequestType.GET)) {
            return requestSpecification.config(config).get(apiPath).then().extract().response();
        }
        Assert.fail("Cant execute and return response for specification: " + requestSpecification + " api path: " +
                apiPath + " and request type " + requestType);
        return null;
    }

    public RequestSpecification getBasicAuthRequestSpec() {
        return given()
                .header("Accept-Charset", "UTF-8").header("Accept-Language", "en")
                .header("Api-Key", "").header("Api-Version", "").header("App-Name", "")
                .header("App-Version", "").header("Authorization", "").header("Device-Id", "")
                .header("Platform", "Undefined, iOS, Android, Web, Server, Desktop")
                .header("Session-Id", "")
                .header("Content-Type", "application/x-www-form-urlencoded");
    }

    public RequestSpecification getBasicRequestSpec() {
        return given()
                .header("Accept-Charset", "UTF-8").header("Accept-Language", "en")
                .header("Api-Key", "").header("Api-Version", "").header("App-Name", "")
                .header("App-Version", "").header("Content-Type", "").header("Device-Id", "")
                .header("Platform", "Undefined, iOS, Android, Web, Server, Desktop")
                .header("Session-Id", "");
    }

    private RequestSpecification requestSpecWithHeaders(String... headers) {
        return requestSpecWithHeaders(given(), headers);
    }

    private RequestSpecification requestSpecWithHeaders(RequestSpecification specification, String... headers) {
        Assertions.assertEquals(0, headers.length % 2,
                "headers amount must be even");
        if (headers.length == 0) {
            return specification;
        }
        for (int i = 0; i < headers.length - 1; i += 2) {
            specification.header(headers[i], headers[i + 1]);
        }
        return specification;
    }

    private RequestSpecification requestSpecWithFormParams(String... formParams) {
        return requestSpecWithFormParams(given(), formParams);
    }

    private RequestSpecification requestSpecWithFormParams(RequestSpecification specification,
                                                           String... formParams) {
        Assertions.assertEquals(0, formParams.length % 2,
                "formParams amount must be even");
        if (formParams.length == 0) {
            return specification;
        }
        for (int i = 0; i < formParams.length - 1; i += 2) {
            specification.formParams(formParams[i], formParams[i + 1]);
        }
        return specification;
    }

    private RequestSpecification requestSpecWithParams(String... params) {
        return requestSpecWithParams(given(), params);
    }

    private RequestSpecification requestSpecWithParams(RequestSpecification specification, String... params) {
        Assertions.assertEquals(0, params.length % 2,
                "params amount must be even");
        if (params.length == 0) {
            return specification;
        }
        for (int i = 0; i < params.length - 1; i += 2) {
            specification.params(params[i], params[i + 1]);
        }
        return specification;
    }

    public enum RequestType {
        POST, GET, DELETE, PUT
    }
}
